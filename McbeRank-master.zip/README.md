# McbeRank
PMMP Plugin, Get your server's rank when player connect.

mcbe.cf에서의 서버순위를 서버에 접속시 표시해줍니다.
단, 반드시 mcbe.cf에 서버가 등륵되어있어야합니다.

이 플러그인은 엔로그님이 제작하셨으며 도끼다이아가 수정하였습니다.
